import mysql from 'mysql2/promise';

const connection = await mysql.createConnection(process.env.DATABASE_URL);

// Check for duplicate IDs
const [duplicates] = await connection.execute(`
  SELECT id, COUNT(*) as count
  FROM jobs
  GROUP BY id
  HAVING count > 1
  LIMIT 10
`);

console.log('Duplicate IDs found:', duplicates.length);
duplicates.forEach(row => {
  console.log(`ID ${row.id}: ${row.count} occurrences`);
});

// Check total jobs
const [total] = await connection.execute('SELECT COUNT(*) as count FROM jobs');
console.log('\nTotal jobs in database:', total[0].count);

// Check unique IDs
const [unique] = await connection.execute('SELECT COUNT(DISTINCT id) as count FROM jobs');
console.log('Unique job IDs:', unique[0].count);

await connection.end();
