# Job Board Integration Documentation

## Overview

The DevOps & SRE Job Board is a full-stack web application that automatically aggregates job listings from multiple sources and displays them in a searchable, filterable interface. The system integrates with your daily job search automation script to keep job listings fresh and up-to-date.

## Architecture

### Components

1. **Frontend (React + Tailwind CSS)**
   - Modern, responsive job board interface
   - Real-time search and filtering by experience level and job source
   - Beautiful hero section with tech-themed background
   - Direct application links for each job

2. **Backend (Express + tRPC)**
   - Public API endpoint: `trpc.jobs.list` - fetches all jobs
   - Database integration with MySQL/TiDB
   - Automatic job deduplication using external IDs

3. **Database (MySQL/TiDB)**
   - `jobs` table stores job listings with the following fields:
     - `id`: Auto-incremented primary key
     - `title`: Job title
     - `company`: Company name
     - `experience`: Required experience level
     - `source`: Job source (Hacker News, JobRight, LinkedIn, etc.)
     - `applicationLink`: Direct link to apply
     - `domain`: Job domain (DevOps/SRE, Cloud Infrastructure, etc.)
     - `level`: Experience level (junior, mid, senior)
     - `externalId`: Unique identifier from source (for deduplication)
     - `createdAt`: Timestamp when job was added
     - `updatedAt`: Timestamp when job was last updated

4. **Automation**
   - Daily job search script runs at 9:00 AM
   - Scans multiple sources: Hacker News, JobRight, LinkedIn, Google Jobs
   - Filters for: 0-7 years experience, US-based companies, non-staffing firms
   - Generates markdown report with structured job data
   - Integration script parses report and updates database

## Setup & Configuration

### Database Migration

The jobs table is automatically created when you run:

```bash
pnpm db:push
```

Or manually execute the migration:

```bash
node server/seedJobs.mjs
```

### Initial Data Population

Seed the database with sample jobs:

```bash
node server/seedJobs.mjs
```

This populates 13 sample jobs from your daily report.

### Environment Variables

The following environment variables are automatically injected:

- `DATABASE_URL`: MySQL/TiDB connection string
- `VITE_APP_ID`: Manus OAuth application ID
- `OAUTH_SERVER_URL`: Manus OAuth backend URL

## API Reference

### Jobs List Endpoint

**Endpoint:** `trpc.jobs.list`

**Method:** GET (public procedure)

**Response:**

```typescript
Job[] = [
  {
    id: number,
    title: string,
    company: string,
    experience: string,
    source: string,
    applicationLink: string,
    domain: string,
    level: "junior" | "mid" | "senior",
    externalId: string | null,
    createdAt: Date,
    updatedAt: Date
  }
]
```

**Example Usage (Frontend):**

```typescript
const { data: jobs, isLoading } = trpc.jobs.list.useQuery();
```

## Database Operations

### Query All Jobs

```typescript
import { getAllJobs } from "./server/db";

const jobs = await getAllJobs();
```

### Upsert Jobs

```typescript
import { upsertJobs } from "./server/db";

const newJobs = [
  {
    title: "DevOps Engineer",
    company: "TechCorp",
    experience: "3-5 years",
    source: "LinkedIn",
    applicationLink: "https://...",
    domain: "DevOps/SRE",
    level: "mid",
    externalId: "linkedin-12345"
  }
];

await upsertJobs(newJobs);
```

### Delete Old Jobs

```typescript
import { deleteOldJobs } from "./server/db";

const thirtyDaysAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
await deleteOldJobs(thirtyDaysAgo);
```

## Automation Integration

### Running the Automation Manually

```bash
node server/runJobSearchAutomation.mjs
```

This script:
1. Executes the Python job search automation
2. Parses the generated markdown report
3. Inserts/updates jobs in the database
4. Cleans up jobs older than 30 days

### Scheduled Execution

The automation is scheduled to run daily at **9:00 AM** via the Manus scheduler.

### Integration Points

The automation script expects:
- Python job search script at: `/home/ubuntu/skills/job-search-automation/scripts/job_search_automation.py`
- Generated report format: `daily_job_report_YYYYMMDD.md`
- Report structure: Markdown table with columns: Title, Company, Experience, Source, Application Link

## Testing

### Run All Tests

```bash
pnpm test
```

### Test Coverage

The test suite (`server/jobs.test.ts`) includes:

- ✓ API returns array of jobs
- ✓ Jobs have all required fields
- ✓ Jobs are sorted by creation date (newest first)
- ✓ Jobs have valid level enum values
- ✓ Jobs have non-empty required fields
- ✓ Public procedure (no authentication required)
- ✓ Jobs from different sources
- ✓ Jobs from different experience levels
- ✓ Jobs with valid domains
- ✓ Unique external IDs
- ✓ Valid application URLs
- ✓ Valid timestamps

All tests pass successfully.

## Frontend Features

### Search

Search jobs by:
- Job title
- Company name
- Domain (DevOps/SRE, Cloud Infrastructure, etc.)

### Filtering

Filter by:
- **Experience Level**: Junior, Mid, Senior
- **Job Source**: Hacker News, JobRight, LinkedIn, Google Jobs

### UI Components

- **Hero Section**: Tech-themed background with project description
- **Sidebar Filters**: Sticky filter panel with toggleable options
- **Job Cards**: Clean cards showing job details with hover effects
- **Apply Button**: Direct link to job application
- **Results Counter**: Shows matching jobs vs. total jobs
- **Empty State**: Helpful message when no jobs match filters

## Deployment

### Build

```bash
pnpm build
```

### Start Production Server

```bash
pnpm start
```

The application will be available at the configured domain.

## Troubleshooting

### Jobs Not Displaying

1. Check if database table exists:
   ```bash
   pnpm db:push
   ```

2. Verify jobs are in database:
   ```bash
   node server/seedJobs.mjs
   ```

3. Check server logs for errors:
   ```bash
   tail -f .manus-logs/devserver.log
   ```

### Automation Not Running

1. Verify automation script exists:
   ```bash
   ls /home/ubuntu/skills/job-search-automation/scripts/job_search_automation.py
   ```

2. Check scheduler status in Manus dashboard

3. Run manually to debug:
   ```bash
   node server/runJobSearchAutomation.mjs
   ```

### Database Connection Issues

1. Verify `DATABASE_URL` environment variable is set
2. Check database connection in Manus dashboard
3. Ensure SSL is enabled for remote connections

## Future Enhancements

- [ ] Add job detail modal with full job description
- [ ] Implement job bookmarking/favorites
- [ ] Add email notifications for new jobs matching criteria
- [ ] Create admin panel for manual job management
- [ ] Add job statistics and trends dashboard
- [ ] Implement user preferences and saved searches
- [ ] Add job application tracking
- [ ] Create RSS feed for job listings

## Support

For issues or questions:
1. Check the logs in `.manus-logs/` directory
2. Review test results with `pnpm test`
3. Verify database connectivity in Manus dashboard
4. Check the automation script at `/home/ubuntu/skills/job-search-automation/`
