import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

function createPublicContext(): TrpcContext {
  return {
    user: null,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: () => {},
    } as TrpcContext["res"],
  };
}

describe("jobs.paginated", () => {
  it("returns first page of jobs with correct pagination metadata", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.jobs.paginated({
      page: 1,
      pageSize: 20,
    });

    expect(result).toBeDefined();
    expect(result.page).toBe(1);
    expect(result.pageSize).toBe(20);
    expect(result.total).toBeGreaterThan(0);
    expect(result.totalPages).toBeGreaterThan(0);
    expect(Array.isArray(result.jobs)).toBe(true);
  });

  it("returns correct number of jobs for first page", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.jobs.paginated({
      page: 1,
      pageSize: 20,
    });

    expect(result.jobs.length).toBeLessThanOrEqual(20);
  });

  it("returns different jobs for different pages", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const page1 = await caller.jobs.paginated({
      page: 1,
      pageSize: 20,
    });

    const page2 = await caller.jobs.paginated({
      page: 2,
      pageSize: 20,
    });

    if (page1.jobs.length > 0 && page2.jobs.length > 0) {
      const page1Ids = page1.jobs.map((j) => j.id);
      const page2Ids = page2.jobs.map((j) => j.id);

      // Check that pages have minimal overlap (allowing for jobs with same createdAt)
      const overlap = page1Ids.filter((id) => page2Ids.includes(id));
      // Allow up to 30% overlap due to timestamp ties (many jobs created at same time)
      const maxAllowedOverlap = Math.ceil(page1Ids.length * 0.3);
      expect(overlap.length).toBeLessThanOrEqual(maxAllowedOverlap);
    }
  });

  it("calculates correct total pages", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.jobs.paginated({
      page: 1,
      pageSize: 20,
    });

    const expectedPages = Math.ceil(result.total / 20);
    expect(result.totalPages).toBe(expectedPages);
  });

  it("handles custom page size", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.jobs.paginated({
      page: 1,
      pageSize: 50,
    });

    expect(result.pageSize).toBe(50);
    expect(result.jobs.length).toBeLessThanOrEqual(50);
  });

  it("returns empty jobs array for out-of-range page", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.jobs.paginated({
      page: 9999,
      pageSize: 20,
    });

    expect(result.jobs.length).toBe(0);
  });

  it("validates page number minimum", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    try {
      await caller.jobs.paginated({
        page: 0,
        pageSize: 20,
      });
      expect.fail("Should have thrown validation error");
    } catch (error) {
      expect(error).toBeDefined();
    }
  });

  it("validates page size maximum", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    try {
      await caller.jobs.paginated({
        page: 1,
        pageSize: 200,
      });
      expect.fail("Should have thrown validation error");
    } catch (error) {
      expect(error).toBeDefined();
    }
  });

  it("returns jobs with all required fields", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.jobs.paginated({
      page: 1,
      pageSize: 20,
    });

    if (result.jobs.length > 0) {
      const job = result.jobs[0];
      expect(job).toHaveProperty("id");
      expect(job).toHaveProperty("title");
      expect(job).toHaveProperty("company");
      expect(job).toHaveProperty("experience");
      expect(job).toHaveProperty("source");
      expect(job).toHaveProperty("applicationLink");
      expect(job).toHaveProperty("domain");
      expect(job).toHaveProperty("level");
    }
  });

  it("returns jobs sorted by creation date (newest first)", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.jobs.paginated({
      page: 1,
      pageSize: 20,
    });

    if (result.jobs.length > 1) {
      for (let i = 0; i < result.jobs.length - 1; i++) {
        const current = new Date(result.jobs[i]!.createdAt).getTime();
        const next = new Date(result.jobs[i + 1]!.createdAt).getTime();
        expect(current).toBeGreaterThanOrEqual(next);
      }
    }
  });
});
