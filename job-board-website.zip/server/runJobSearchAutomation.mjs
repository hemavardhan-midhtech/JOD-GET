#!/usr/bin/env node

import { spawn } from 'child_process';
import mysql from 'mysql2/promise';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

/**
 * Integration script that:
 * 1. Runs the daily job search automation script
 * 2. Parses the generated report
 * 3. Inserts/updates jobs in the database
 * 4. Cleans up old jobs (older than 30 days)
 */

async function runJobSearchAutomation() {
  console.log('[Job Board] Starting daily job search automation...');
  
  try {
    // Run the Python job search automation script
    console.log('[Job Board] Running job search script...');
    const automationScript = '/home/ubuntu/skills/job-search-automation/scripts/job_search_automation.py';
    
    await new Promise((resolve, reject) => {
      const process = spawn('python3.11', [automationScript], {
        cwd: '/home/ubuntu',
        stdio: 'inherit'
      });
      
      process.on('close', (code) => {
        if (code === 0) {
          console.log('[Job Board] Job search script completed successfully');
          resolve();
        } else {
          reject(new Error(`Job search script failed with code ${code}`));
        }
      });
      
      process.on('error', (err) => {
        reject(new Error(`Failed to run job search script: ${err.message}`));
      });
    });
    
    // Parse the generated report and extract jobs
    console.log('[Job Board] Parsing job report...');
    const jobs = await parseJobReport();
    
    if (jobs.length === 0) {
      console.log('[Job Board] No new jobs found in report');
      return;
    }
    
    console.log(`[Job Board] Found ${jobs.length} jobs to insert/update`);
    
    // Insert/update jobs in database
    await insertJobsToDatabase(jobs);
    
    // Clean up old jobs (older than 30 days)
    await cleanupOldJobs();
    
    console.log('[Job Board] ✓ Daily job search automation completed successfully');
  } catch (error) {
    console.error('[Job Board] Error during automation:', error);
    throw error;
  }
}

async function parseJobReport() {
  /**
   * This function would parse the generated daily_job_report_*.md file
   * For now, we'll return an empty array since the seed data is already in the DB
   * In production, this would extract jobs from the markdown report
   */
  
  // Example structure of jobs to be returned:
  // {
  //   title: string,
  //   company: string,
  //   experience: string,
  //   source: string,
  //   applicationLink: string,
  //   domain: string,
  //   level: 'junior' | 'mid' | 'senior',
  //   externalId: string (unique identifier)
  // }
  
  return [];
}

async function insertJobsToDatabase(jobs) {
  const connection = await mysql.createConnection(process.env.DATABASE_URL);
  
  try {
    for (const job of jobs) {
      const query = `
        INSERT INTO jobs (title, company, experience, source, applicationLink, domain, level, externalId)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE
          title = VALUES(title),
          company = VALUES(company),
          experience = VALUES(experience),
          source = VALUES(source),
          applicationLink = VALUES(applicationLink),
          domain = VALUES(domain),
          level = VALUES(level),
          updatedAt = NOW()
      `;
      
      await connection.execute(query, [
        job.title,
        job.company,
        job.experience,
        job.source,
        job.applicationLink,
        job.domain,
        job.level,
        job.externalId
      ]);
    }
    
    console.log(`[Job Board] Successfully inserted/updated ${jobs.length} jobs`);
  } finally {
    await connection.end();
  }
}

async function cleanupOldJobs() {
  const connection = await mysql.createConnection(process.env.DATABASE_URL);
  
  try {
    // Delete jobs older than 30 days
    const thirtyDaysAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
    
    const [result] = await connection.execute(
      'DELETE FROM jobs WHERE createdAt < ?',
      [thirtyDaysAgo]
    );
    
    if (result.affectedRows > 0) {
      console.log(`[Job Board] Cleaned up ${result.affectedRows} old jobs`);
    }
  } finally {
    await connection.end();
  }
}

// Run the automation
runJobSearchAutomation().catch(err => {
  console.error('[Job Board] Fatal error:', err);
  process.exit(1);
});
