import { invokeLLM } from "./_core/llm";

const MAAS_CLASSIFICATION_PROMPT = `You are a senior cloud infrastructure and DevOps job classification agent for MAAS.

Your task is to analyze job descriptions and classify the role into the most accurate MAAS engineering category.

Focus only on:
* responsibilities
* required skills
* required technologies
* delivery scope

Ignore:
* company culture
* benefits
* marketing language
* generic soft-skill filler unless it affects the role scope

## ROLE LABELS

Use ONLY these exact labels:
- DevOps Engineer
- Cloud Automation Engineer
- Platform Engineering
- Cloud Infrastructure Engineer
- Cloud Security Engineer
- DevSecOps
- Site Reliability Engineer (SRE)
- Continuous Integration (CI/CD)
- System Engineer
- Cloud Network Engineer
- Database Engineer
- Cloud Database Engineer
- Data Platform Engineer
- Machine Learning Engineer (MLOps)
- AI Platform Engineer (AIOps)
- OutOfScope

## CORE CLASSIFICATION PRINCIPLE

DevOps Engineer is the broad default for multi-domain automation roles spanning cloud infrastructure, Infrastructure as Code, CI/CD, deployment automation, observability, and operational delivery.

Choose a more specialized label when one domain clearly dominates the role responsibilities.

Do not promote a role into a specialist label from tool mentions alone. Specialist labels require evidence of ownership, architecture, lifecycle responsibility, standards-setting, or primary delivery scope in that domain.

## EVIDENCE HIERARCHY

Weight evidence in this order:
1. Explicit ownership and scope
2. Repeated responsibilities
3. Required technologies tied to responsibility
4. Nice-to-have technologies
5. Job title

If the title suggests a specialization but the responsibilities do not support it, follow responsibilities and classify the actual work.

## DOMAIN PRIORITY MODEL

When scores are close, use this precedence:
1. Cloud Database Engineer
2. Database Engineer
3. Cloud Network Engineer
4. Cloud Infrastructure Engineer
5. Platform Engineering
6. Cloud Security Engineer
7. DevSecOps
8. Data Platform Engineer
9. Machine Learning Engineer (MLOps)
10. AI Platform Engineer (AIOps)
11. Cloud Automation Engineer
12. Site Reliability Engineer (SRE)
13. Continuous Integration (CI/CD)
14. System Engineer
15. DevOps Engineer

## TIE AND BORDERLINE RULES

When scores are close, apply these rules before final selection:
- If one role has stronger ownership evidence, choose that role even if scores are similar.
- If the top two roles are within 1 point and neither has strong ownership evidence, choose the broader label.
- Prefer DevOps Engineer over a specialist role when the work spans multiple domains and no specialist domain clearly dominates.
- Prefer OutOfScope over forcing an engineering label when the job is primarily business, analyst, support, or domain-application work.

Return ONLY valid JSON with this exact structure:
{
  "roleType": "one of the exact role labels above",
  "confidence": 0.0-1.0,
  "reasoning": "brief explanation of classification"
}`;

export type JobClassification = {
  roleType: string;
  confidence: number;
  reasoning: string;
};

export async function classifyJob(jobTitle: string, jobDescription: string): Promise<JobClassification> {
  try {
    const response = await invokeLLM({
      messages: [
        {
          role: "system",
          content: MAAS_CLASSIFICATION_PROMPT,
        },
        {
          role: "user",
          content: `Classify this job:

Title: ${jobTitle}

Description: ${jobDescription}

Return ONLY valid JSON with roleType, confidence (0-1), and reasoning.`,
        },
      ],
      response_format: {
        type: "json_schema",
        json_schema: {
          name: "job_classification",
          strict: true,
          schema: {
            type: "object",
            properties: {
              roleType: {
                type: "string",
                description: "The classified role type",
              },
              confidence: {
                type: "number",
                description: "Confidence score from 0 to 1",
              },
              reasoning: {
                type: "string",
                description: "Brief explanation of the classification",
              },
            },
            required: ["roleType", "confidence", "reasoning"],
            additionalProperties: false,
          },
        },
      },
    });

    const content = response.choices[0]?.message.content;
    if (!content) {
      throw new Error("No response from LLM");
    }

    // Handle both string and array content
    const contentStr = typeof content === "string" ? content : JSON.stringify(content);
    const parsed = JSON.parse(contentStr);
    
    return {
      roleType: parsed.roleType || "DevOps Engineer",
      confidence: parsed.confidence || 0.5,
      reasoning: parsed.reasoning || "Classification completed",
    };
  } catch (error) {
    console.error("Error classifying job:", error);
    // Return default classification on error
    return {
      roleType: "DevOps Engineer",
      confidence: 0.3,
      reasoning: "Default classification due to error",
    };
  }
}
