import mysql from 'mysql2/promise';
import fs from 'fs';

const jobs = JSON.parse(fs.readFileSync('/home/ubuntu/comprehensive_jobs.json', 'utf-8'));

async function clearAndUpdate() {
  const connection = await mysql.createConnection(process.env.DATABASE_URL);
  
  try {
    console.log('Truncating jobs table...');
    await connection.execute('TRUNCATE TABLE jobs');
    
    console.log(`Inserting ${jobs.length} updated jobs...`);
    
    let inserted = 0;
    for (const job of jobs) {
      try {
        await connection.execute(
          `INSERT INTO jobs (title, company, experience, source, applicationLink, domain, level, externalId, createdAt, updatedAt)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          [
            job.title,
            job.company,
            job.experience,
            job.source,
            job.applicationLink,
            job.domain,
            job.level,
            job.externalId,
            new Date(job.createdAt),
            new Date(job.updatedAt)
          ]
        );
        inserted++;
        
        if (inserted % 100 === 0) {
          console.log(`Progress: ${inserted} inserted...`);
        }
      } catch (err) {
        console.error(`Error inserting job ${job.externalId}:`, err.message);
      }
    }
    
    const [result] = await connection.execute('SELECT COUNT(*) as count FROM jobs');
    const totalJobs = result[0].count;
    
    console.log(`\n✅ Update complete!`);
    console.log(`  Inserted: ${inserted}`);
    console.log(`  Total jobs in database: ${totalJobs}`);
    
  } catch (error) {
    console.error('Error:', error);
  } finally {
    await connection.end();
  }
}

clearAndUpdate();
