import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import { getAllJobs, getDb } from "./db";
import { z } from "zod";
import { desc, eq, sql } from "drizzle-orm";
import { jobs } from "../drizzle/schema";

export const appRouter = router({
    // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  jobs: router({
    list: publicProcedure.query(async () => {
      return await getAllJobs();
    }),
    
    byRoleType: publicProcedure
      .input(
        z.object({
          roleType: z.string(),
          page: z.number().min(1).default(1),
          pageSize: z.number().min(1).max(100).default(20),
        })
      )
      .query(async ({ input }) => {
        const db = await getDb();
        if (!db) {
          return {
            jobs: [],
            total: 0,
            page: input.page,
            pageSize: input.pageSize,
            totalPages: 0,
          };
        }

        try {
          // Get total count for this role type
          const countResult = await db.execute(
            sql`SELECT COUNT(*) as count FROM jobs WHERE roleType = ${input.roleType}`
          );
          const total =
            (countResult[0] as unknown as Array<{ count: number }>)[0]?.count || 0;

          // Calculate offset
          const offset = (input.page - 1) * input.pageSize;

          // Get paginated results
          const result = await db.execute(
            sql`SELECT * FROM jobs WHERE roleType = ${input.roleType} ORDER BY createdAt DESC LIMIT ${input.pageSize} OFFSET ${offset}`
          );
          const typedResult = (result[0] as unknown as Array<any>);

          const totalPages = Math.ceil(total / input.pageSize);

          return {
            jobs: typedResult,
            total,
            page: input.page,
            pageSize: input.pageSize,
            totalPages,
          };
        } catch (error) {
          console.error("[Database] Failed to get jobs by role type:", error);
          return {
            jobs: [],
            total: 0,
            page: input.page,
            pageSize: input.pageSize,
            totalPages: 0,
          };
        }
      }),
    
    paginated: publicProcedure
      .input(
        z.object({
          page: z.number().min(1).default(1),
          pageSize: z.number().min(1).max(100).default(20),
        })
      )
      .query(async ({ input }) => {
        const db = await getDb();
        if (!db) {
          return {
            jobs: [],
            total: 0,
            page: input.page,
            pageSize: input.pageSize,
            totalPages: 0,
          };
        }

        try {
          // Get total count
          const countResult = await db.execute(
            "SELECT COUNT(*) as count FROM jobs"
          );
          const total =
            (countResult[0] as unknown as Array<{ count: number }>)[0]?.count || 0;

          // Calculate offset
          const offset = (input.page - 1) * input.pageSize;

          // Get paginated results
          const result = await db
            .select()
            .from(jobs)
            .orderBy(desc(jobs.createdAt))
            .limit(input.pageSize)
            .offset(offset);

          const totalPages = Math.ceil(total / input.pageSize);

          return {
            jobs: result,
            total,
            page: input.page,
            pageSize: input.pageSize,
            totalPages,
          };
        } catch (error) {
          console.error("[Database] Failed to get paginated jobs:", error);
          return {
            jobs: [],
            total: 0,
            page: input.page,
            pageSize: input.pageSize,
            totalPages: 0,
          };
        }
      }),
  }),

  analytics: router({
    // Get overall statistics
    stats: publicProcedure.query(async () => {
      const db = await getDb();
      if (!db) {
        return {
          totalJobs: 0,
          totalCompanies: 0,
          totalDomains: 0,
          averageJobsPerCompany: 0,
        };
      }

      try {
        const allJobs = await db.select().from(jobs);
        
        const uniqueCompanies = new Set(allJobs.map(j => j.company)).size;
        const uniqueDomains = new Set(allJobs.map(j => j.domain)).size;
        const avgJobsPerCompany = uniqueCompanies > 0 ? allJobs.length / uniqueCompanies : 0;

        return {
          totalJobs: allJobs.length,
          totalCompanies: uniqueCompanies,
          totalDomains: uniqueDomains,
          averageJobsPerCompany: Math.round(avgJobsPerCompany * 100) / 100,
        };
      } catch (error) {
        console.error("[Analytics] Failed to get stats:", error);
        return {
          totalJobs: 0,
          totalCompanies: 0,
          totalDomains: 0,
          averageJobsPerCompany: 0,
        };
      }
    }),

    // Get job distribution by experience level
    jobsByLevel: publicProcedure.query(async () => {
      const db = await getDb();
      if (!db) {
        return [];
      }

      try {
        const allJobs = await db.select().from(jobs);
        const distribution = new Map<string, number>();

        allJobs.forEach(job => {
          const level = job.level || "Unknown";
          distribution.set(level, (distribution.get(level) || 0) + 1);
        });

        return Array.from(distribution.entries()).map(([level, count]) => ({
          level: level.charAt(0).toUpperCase() + level.slice(1),
          count,
          percentage: Math.round((count / allJobs.length) * 100),
        }));
      } catch (error) {
        console.error("[Analytics] Failed to get jobs by level:", error);
        return [];
      }
    }),

    // Get job distribution by role type
    jobsByRoleType: publicProcedure.query(async () => {
      const db = await getDb();
      if (!db) {
        return [];
      }

      try {
        const allJobs = await db.select().from(jobs);
        const distribution = new Map<string, number>();

        allJobs.forEach(job => {
          const roleType = job.roleType || "DevOps Engineer";
          distribution.set(roleType, (distribution.get(roleType) || 0) + 1);
        });

        return Array.from(distribution.entries())
          .map(([roleType, count]) => ({
            roleType,
            count,
            percentage: Math.round((count / allJobs.length) * 100),
          }))
          .sort((a, b) => b.count - a.count);
      } catch (error) {
        console.error("[Analytics] Failed to get jobs by role type:", error);
        return [];
      }
    }),

    // Get job distribution by domain
    jobsByDomain: publicProcedure.query(async () => {
      const db = await getDb();
      if (!db) {
        return [];
      }

      try {
        const allJobs = await db.select().from(jobs);
        const distribution = new Map<string, number>();

        allJobs.forEach(job => {
          const domain = job.domain || "Unknown";
          distribution.set(domain, (distribution.get(domain) || 0) + 1);
        });

        return Array.from(distribution.entries())
          .map(([domain, count]) => ({
            domain,
            count,
            percentage: Math.round((count / allJobs.length) * 100),
          }))
          .sort((a, b) => b.count - a.count);
      } catch (error) {
        console.error("[Analytics] Failed to get jobs by domain:", error);
        return [];
      }
    }),

    // Get top hiring companies
    topCompanies: publicProcedure
      .input(z.object({ limit: z.number().min(1).max(50).default(10) }))
      .query(async ({ input }) => {
        const db = await getDb();
        if (!db) {
          return [];
        }

        try {
          const allJobs = await db.select().from(jobs);
          const companyCount = new Map<string, number>();

          allJobs.forEach(job => {
            const company = job.company || "Unknown";
            companyCount.set(company, (companyCount.get(company) || 0) + 1);
          });

          return Array.from(companyCount.entries())
            .map(([company, count]) => ({
              company,
              jobCount: count,
              percentage: Math.round((count / allJobs.length) * 100),
            }))
            .sort((a, b) => b.jobCount - a.jobCount)
            .slice(0, input.limit);
        } catch (error) {
          console.error("[Analytics] Failed to get top companies:", error);
          return [];
        }
      }),

    // Get job distribution by source
    jobsBySource: publicProcedure.query(async () => {
      const db = await getDb();
      if (!db) {
        return [];
      }

      try {
        const allJobs = await db.select().from(jobs);
        const distribution = new Map<string, number>();

        allJobs.forEach(job => {
          const source = job.source || "Unknown";
          distribution.set(source, (distribution.get(source) || 0) + 1);
        });

        return Array.from(distribution.entries())
          .map(([source, count]) => ({
            source,
            count,
            percentage: Math.round((count / allJobs.length) * 100),
          }))
          .sort((a, b) => b.count - a.count);
      } catch (error) {
        console.error("[Analytics] Failed to get jobs by source:", error);
        return [];
      }
    }),

    // Get experience level distribution
    experienceDistribution: publicProcedure.query(async () => {
      const db = await getDb();
      if (!db) {
        return [];
      }

      try {
        const allJobs = await db.select().from(jobs);
        const distribution = new Map<string, number>();

        allJobs.forEach(job => {
          const exp = job.experience || "Unknown";
          distribution.set(exp, (distribution.get(exp) || 0) + 1);
        });

        return Array.from(distribution.entries())
          .map(([experience, count]) => ({
            experience,
            count,
            percentage: Math.round((count / allJobs.length) * 100),
          }))
          .sort((a, b) => b.count - a.count);
      } catch (error) {
        console.error("[Analytics] Failed to get experience distribution:", error);
        return [];
      }
    }),
  }),
});

export type AppRouter = typeof appRouter;
