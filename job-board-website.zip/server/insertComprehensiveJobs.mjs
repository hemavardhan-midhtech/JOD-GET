import mysql from 'mysql2/promise';
import fs from 'fs';
import path from 'path';

const jobs = JSON.parse(fs.readFileSync('/home/ubuntu/comprehensive_jobs.json', 'utf-8'));

async function insertJobs() {
  const connection = await mysql.createConnection(process.env.DATABASE_URL);
  
  try {
    console.log(`Inserting ${jobs.length} jobs into the database...`);
    
    // Clear existing jobs (optional - comment out if you want to keep them)
    // await connection.execute('DELETE FROM jobs');
    
    let inserted = 0;
    let skipped = 0;
    
    for (const job of jobs) {
      try {
        // Check if job already exists by externalId
        const [existing] = await connection.execute(
          'SELECT id FROM jobs WHERE externalId = ?',
          [job.externalId]
        );
        
        if (existing.length > 0) {
          skipped++;
          continue;
        }
        
        await connection.execute(
          `INSERT INTO jobs (title, company, experience, source, applicationLink, domain, level, externalId, createdAt, updatedAt)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          [
            job.title,
            job.company,
            job.experience,
            job.source,
            job.applicationLink,
            job.domain,
            job.level,
            job.externalId,
            new Date(job.createdAt),
            new Date(job.updatedAt)
          ]
        );
        inserted++;
        
        if (inserted % 50 === 0) {
          console.log(`Progress: ${inserted} inserted, ${skipped} skipped...`);
        }
      } catch (err) {
        console.error(`Error inserting job ${job.externalId}:`, err.message);
      }
    }
    
    // Get total count
    const [result] = await connection.execute('SELECT COUNT(*) as count FROM jobs');
    const totalJobs = result[0].count;
    
    console.log(`\n✅ Insertion complete!`);
    console.log(`  Inserted: ${inserted}`);
    console.log(`  Skipped (duplicates): ${skipped}`);
    console.log(`  Total jobs in database: ${totalJobs}`);
    
  } catch (error) {
    console.error('Error:', error);
  } finally {
    await connection.end();
  }
}

insertJobs();
