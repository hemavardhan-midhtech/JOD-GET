import { describe, it, expect } from "vitest";
import { appRouter } from "./routers";
import type { Job } from "../drizzle/schema";

function createPublicContext() {
  return {
    user: null,
    req: {
      protocol: "https",
      headers: {},
    },
    res: {},
  };
}

describe("jobs.list", () => {
  it("returns an array of jobs", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const jobs = await caller.jobs.list();

    expect(Array.isArray(jobs)).toBe(true);
    expect(jobs.length).toBeGreaterThan(0);
  });

  it("returns jobs with all required fields", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const jobs = await caller.jobs.list();

    jobs.forEach((job) => {
      expect(job).toHaveProperty("id");
      expect(job).toHaveProperty("title");
      expect(job).toHaveProperty("company");
      expect(job).toHaveProperty("domain");
      expect(job).toHaveProperty("level");
      expect(job).toHaveProperty("experience");
      expect(job).toHaveProperty("source");
      expect(job).toHaveProperty("applicationLink");
    });
  });

  it("returns jobs with valid experience levels", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const jobs = await caller.jobs.list();
    const validLevels = ["junior", "mid", "senior"];

    jobs.forEach((job) => {
      expect(validLevels).toContain((job as Job).level);
    });
  });

  it("returns jobs with unique IDs", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const jobs = await caller.jobs.list();
    const ids = jobs.map((job) => job.id);
    const uniqueIds = new Set(ids);

    expect(uniqueIds.size).toBe(ids.length);
  });

  it("returns jobs with non-empty titles and companies", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const jobs = await caller.jobs.list();

    jobs.forEach((job) => {
      expect((job as Job).title).toBeTruthy();
      expect((job as Job).company).toBeTruthy();
    });
  });

  it("returns jobs with valid sources", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const jobs = await caller.jobs.list();

    jobs.forEach((job) => {
      expect((job as Job).source).toBeTruthy();
    });
  });

  it("returns jobs with valid application links", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const jobs = await caller.jobs.list();

    jobs.forEach((job) => {
      expect((job as Job).applicationLink).toBeTruthy();
      expect((job as Job).applicationLink).toMatch(/^https?:\/\//);
    });
  });

  it("returns jobs with multiple experience levels", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const jobs = await caller.jobs.list();
    const levels = new Set(jobs.map((job) => (job as Job).level));

    expect(levels.size).toBeGreaterThan(0);
  });

  it("returns jobs with valid domains", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const jobs = await caller.jobs.list();

    const validDomains = [
      "DevOps",
      "DevOps/SRE",
      "Devops",
      "SRE",
      "Sre",
      "Cloud",
      "Cloud Infrastructure",
      "Cloud Automation",
      "System Engineering",
      "Database",
    ];

    jobs.forEach((job) => {
      expect(validDomains).toContain((job as Job).domain);
    });
  });
});
