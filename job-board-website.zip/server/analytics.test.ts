import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

function createPublicContext(): TrpcContext {
  return {
    user: null,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: () => {},
    } as TrpcContext["res"],
  };
}

describe("analytics endpoints", () => {
  it("returns overall statistics", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const stats = await caller.analytics.stats();

    expect(stats).toBeDefined();
    expect(stats).toHaveProperty("totalJobs");
    expect(stats).toHaveProperty("totalCompanies");
    expect(stats).toHaveProperty("totalDomains");
    expect(stats).toHaveProperty("averageJobsPerCompany");
    expect(stats.totalJobs).toBeGreaterThan(0);
    expect(stats.totalCompanies).toBeGreaterThan(0);
  });

  it("returns jobs by experience level", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const jobsByLevel = await caller.analytics.jobsByLevel();

    expect(Array.isArray(jobsByLevel)).toBe(true);
    expect(jobsByLevel.length).toBeGreaterThan(0);

    jobsByLevel.forEach((item) => {
      expect(item).toHaveProperty("level");
      expect(item).toHaveProperty("count");
      expect(item).toHaveProperty("percentage");
      expect(item.count).toBeGreaterThan(0);
      expect(item.percentage).toBeGreaterThanOrEqual(0);
      expect(item.percentage).toBeLessThanOrEqual(100);
    });
  });

  it("returns jobs by domain", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const jobsByDomain = await caller.analytics.jobsByDomain();

    expect(Array.isArray(jobsByDomain)).toBe(true);
    expect(jobsByDomain.length).toBeGreaterThan(0);

    jobsByDomain.forEach((item) => {
      expect(item).toHaveProperty("domain");
      expect(item).toHaveProperty("count");
      expect(item).toHaveProperty("percentage");
      expect(item.count).toBeGreaterThan(0);
    });
  });

  it("returns top companies", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const topCompanies = await caller.analytics.topCompanies({ limit: 10 });

    expect(Array.isArray(topCompanies)).toBe(true);
    expect(topCompanies.length).toBeLessThanOrEqual(10);

    topCompanies.forEach((item) => {
      expect(item).toHaveProperty("company");
      expect(item).toHaveProperty("jobCount");
      expect(item).toHaveProperty("percentage");
      expect(item.jobCount).toBeGreaterThan(0);
    });
  });

  it("returns jobs by source", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const jobsBySource = await caller.analytics.jobsBySource();

    expect(Array.isArray(jobsBySource)).toBe(true);
    expect(jobsBySource.length).toBeGreaterThan(0);

    jobsBySource.forEach((item) => {
      expect(item).toHaveProperty("source");
      expect(item).toHaveProperty("count");
      expect(item).toHaveProperty("percentage");
      expect(item.count).toBeGreaterThan(0);
    });
  });

  it("returns experience distribution", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const experienceDistribution = await caller.analytics.experienceDistribution();

    expect(Array.isArray(experienceDistribution)).toBe(true);
    expect(experienceDistribution.length).toBeGreaterThan(0);

    experienceDistribution.forEach((item) => {
      expect(item).toHaveProperty("experience");
      expect(item).toHaveProperty("count");
      expect(item).toHaveProperty("percentage");
      expect(item.count).toBeGreaterThan(0);
    });
  });
});
