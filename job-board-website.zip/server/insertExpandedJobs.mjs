import mysql from 'mysql2/promise';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

/**
 * Script to insert expanded job listings into the database
 */

const expandedJobs = [
  // Junior Level Jobs (99 total)
  ...Array.from({ length: 33 }, (_, i) => ({
    title: `DevOps Engineer (Junior) - ${i + 1}`,
    company: `Tech Company ${i + 1}`,
    experience: '0-2 years',
    source: 'Sample Data',
    applicationLink: `https://example.com/jobs/junior-devops-${i + 1}`,
    domain: 'DevOps/SRE',
    level: 'junior',
    externalId: `job-junior-${i + 1}`
  })),
  ...Array.from({ length: 33 }, (_, i) => ({
    title: `Cloud Infrastructure Engineer (Junior) - ${i + 1}`,
    company: `Cloud Company ${i + 1}`,
    experience: '0-2 years',
    source: 'Sample Data',
    applicationLink: `https://example.com/jobs/junior-cloud-${i + 1}`,
    domain: 'Cloud Infrastructure',
    level: 'junior',
    externalId: `job-junior-cloud-${i + 1}`
  })),
  ...Array.from({ length: 33 }, (_, i) => ({
    title: `Site Reliability Engineer (Junior) - ${i + 1}`,
    company: `SRE Company ${i + 1}`,
    experience: '0-2 years',
    source: 'Sample Data',
    applicationLink: `https://example.com/jobs/junior-sre-${i + 1}`,
    domain: 'DevOps/SRE',
    level: 'junior',
    externalId: `job-junior-sre-${i + 1}`
  })),
  
  // Mid Level Jobs (99 total)
  ...Array.from({ length: 33 }, (_, i) => ({
    title: `DevOps Engineer (Mid-Level) - ${i + 1}`,
    company: `Enterprise ${i + 1}`,
    experience: '3-5 years',
    source: 'Sample Data',
    applicationLink: `https://example.com/jobs/mid-devops-${i + 1}`,
    domain: 'DevOps/SRE',
    level: 'mid',
    externalId: `job-mid-${i + 1}`
  })),
  ...Array.from({ length: 33 }, (_, i) => ({
    title: `Cloud Architect (Mid-Level) - ${i + 1}`,
    company: `Cloud Solutions ${i + 1}`,
    experience: '3-5 years',
    source: 'Sample Data',
    applicationLink: `https://example.com/jobs/mid-cloud-${i + 1}`,
    domain: 'Cloud Infrastructure',
    level: 'mid',
    externalId: `job-mid-cloud-${i + 1}`
  })),
  ...Array.from({ length: 33 }, (_, i) => ({
    title: `Systems Engineer (Mid-Level) - ${i + 1}`,
    company: `Infrastructure Corp ${i + 1}`,
    experience: '3-5 years',
    source: 'Sample Data',
    applicationLink: `https://example.com/jobs/mid-systems-${i + 1}`,
    domain: 'System Engineering',
    level: 'mid',
    externalId: `job-mid-systems-${i + 1}`
  })),
  
  // Senior Level Jobs (99 total)
  ...Array.from({ length: 33 }, (_, i) => ({
    title: `Senior DevOps Engineer - ${i + 1}`,
    company: `Tech Leader ${i + 1}`,
    experience: '5-7 years',
    source: 'Sample Data',
    applicationLink: `https://example.com/jobs/senior-devops-${i + 1}`,
    domain: 'DevOps/SRE',
    level: 'senior',
    externalId: `job-senior-${i + 1}`
  })),
  ...Array.from({ length: 33 }, (_, i) => ({
    title: `Principal Cloud Engineer - ${i + 1}`,
    company: `Cloud Giant ${i + 1}`,
    experience: '5-7 years',
    source: 'Sample Data',
    applicationLink: `https://example.com/jobs/senior-cloud-${i + 1}`,
    domain: 'Cloud Infrastructure',
    level: 'senior',
    externalId: `job-senior-cloud-${i + 1}`
  })),
  ...Array.from({ length: 33 }, (_, i) => ({
    title: `Staff Infrastructure Engineer - ${i + 1}`,
    company: `Tech Innovator ${i + 1}`,
    experience: '5-7 years',
    source: 'Sample Data',
    applicationLink: `https://example.com/jobs/senior-staff-${i + 1}`,
    domain: 'System Engineering',
    level: 'senior',
    externalId: `job-senior-staff-${i + 1}`
  }))
];

async function insertExpandedJobs() {
  const connection = await mysql.createConnection(process.env.DATABASE_URL);
  
  try {
    console.log(`Inserting ${expandedJobs.length} expanded jobs into database...`);
    
    let inserted = 0;
    let updated = 0;
    
    for (const job of expandedJobs) {
      try {
        const query = `
          INSERT INTO jobs (title, company, experience, source, applicationLink, domain, level, externalId)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?)
          ON DUPLICATE KEY UPDATE
            title = VALUES(title),
            company = VALUES(company),
            experience = VALUES(experience),
            source = VALUES(source),
            applicationLink = VALUES(applicationLink),
            domain = VALUES(domain),
            level = VALUES(level),
            updatedAt = NOW()
        `;
        
        const result = await connection.execute(query, [
          job.title,
          job.company,
          job.experience,
          job.source,
          job.applicationLink,
          job.domain,
          job.level,
          job.externalId
        ]);
        
        if (result[0].affectedRows === 1) {
          inserted++;
        } else if (result[0].affectedRows === 2) {
          updated++;
        }
      } catch (error) {
        console.error(`Error inserting job ${job.externalId}:`, error.message);
      }
    }
    
    console.log(`✓ Successfully inserted ${inserted} new jobs`);
    console.log(`✓ Successfully updated ${updated} existing jobs`);
    console.log(`✓ Total jobs in database: ${inserted + updated}`);
    
  } catch (error) {
    console.error("Error inserting jobs:", error);
    throw error;
  } finally {
    await connection.end();
  }
}

insertExpandedJobs().catch(err => {
  console.error("Fatal error:", err);
  process.exit(1);
});
