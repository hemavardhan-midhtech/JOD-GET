import fs from 'fs';
import path from 'path';
import mysql from 'mysql2/promise';

/**
 * Seed script to populate jobs from the daily report into the database
 * Run with: node server/seedJobs.mjs
 */

const jobsData = [
  {
    title: "Head of Engineering & Infrastructure",
    company: "Head of Engineering & Infrastructure",
    experience: "5-7 years",
    source: "Hacker News",
    applicationLink: "https://news.ycombinator.com/item?id=47219761",
    domain: "DevOps/SRE",
    level: "senior",
    externalId: "hn-47219761"
  },
  {
    title: "DevOps/SRE Role",
    company: "Suppmatch",
    experience: "0-7 years",
    source: "Hacker News",
    applicationLink: "https://news.ycombinator.com/item?id=47307796",
    domain: "DevOps/SRE",
    level: "mid",
    externalId: "hn-47307796"
  },
  {
    title: "DevOps/SRE Role",
    company: "Marketer.com",
    experience: "0-7 years",
    source: "Hacker News",
    applicationLink: "https://news.ycombinator.com/item?id=47320714",
    domain: "DevOps/SRE",
    level: "mid",
    externalId: "hn-47320714"
  },
  {
    title: "DevOps/SRE Role",
    company: "Suppmatch",
    experience: "0-7 years",
    source: "Hacker News",
    applicationLink: "https://news.ycombinator.com/item?id=47307830",
    domain: "DevOps/SRE",
    level: "mid",
    externalId: "hn-47307830"
  },
  {
    title: "DevOps/SRE Role",
    company: "Deep Systems",
    experience: "5-7 years",
    source: "Hacker News",
    applicationLink: "https://news.ycombinator.com/item?id=47220897",
    domain: "DevOps/SRE",
    level: "senior",
    externalId: "hn-47220897"
  },
  {
    title: "DevOps/SRE Role",
    company: "Ford Motor Company",
    experience: "0-7 years",
    source: "Hacker News",
    applicationLink: "https://news.ycombinator.com/item?id=47224124",
    domain: "DevOps/SRE",
    level: "mid",
    externalId: "hn-47224124"
  },
  {
    title: "DevOps/SRE Role",
    company: "Radar Labs",
    experience: "0-7 years",
    source: "Hacker News",
    applicationLink: "https://news.ycombinator.com/item?id=47224026",
    domain: "DevOps/SRE",
    level: "mid",
    externalId: "hn-47224026"
  },
  {
    title: "DevOps/SRE Role",
    company: "Hacker News Post",
    experience: "0-7 years",
    source: "Hacker News",
    applicationLink: "https://news.ycombinator.com/item?id=47324911",
    domain: "DevOps/SRE",
    level: "mid",
    externalId: "hn-47324911"
  },
  {
    title: "DevOps/SRE Role",
    company: "Crossnokaye",
    experience: "5-7 years",
    source: "Hacker News",
    applicationLink: "https://news.ycombinator.com/item?id=47224874",
    domain: "DevOps/SRE",
    level: "senior",
    externalId: "hn-47224874"
  },
  {
    title: "DevOps/SRE Role",
    company: "Bitrise (YC, CI/CD for DevOps)",
    experience: "0-7 years",
    source: "Hacker News",
    applicationLink: "https://news.ycombinator.com/item?id=47309646",
    domain: "DevOps/SRE",
    level: "mid",
    externalId: "hn-47309646"
  },
  {
    title: "DevOps Engineer (Junior)",
    company: "Oddball",
    experience: "1+ years",
    source: "JobRight",
    applicationLink: "https://jobright.ai/jobs/junior-devops-engineer-jobs-in-united-states",
    domain: "DevOps/SRE",
    level: "junior",
    externalId: "jr-oddball-devops"
  },
  {
    title: "Junior DevOps Engineer",
    company: "SimpliSafe",
    experience: "Junior",
    source: "JobRight",
    applicationLink: "https://jobright.ai/jobs/junior-devops-engineer-jobs-in-united-states",
    domain: "DevOps/SRE",
    level: "junior",
    externalId: "jr-simplisafe-devops"
  },
  {
    title: "Junior DevOps Engineer",
    company: "Vultr",
    experience: "Junior",
    source: "JobRight",
    applicationLink: "https://jobright.ai/jobs/junior-devops-engineer-jobs-in-united-states",
    domain: "DevOps/SRE",
    level: "junior",
    externalId: "jr-vultr-devops"
  }
];

async function seedJobs() {
  const connection = await mysql.createConnection(process.env.DATABASE_URL);
  
  try {
    console.log("Seeding jobs into database...");
    
    for (const job of jobsData) {
      const query = `
        INSERT INTO jobs (title, company, experience, source, applicationLink, domain, level, externalId)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE
          title = VALUES(title),
          company = VALUES(company),
          experience = VALUES(experience),
          source = VALUES(source),
          applicationLink = VALUES(applicationLink),
          domain = VALUES(domain),
          level = VALUES(level),
          updatedAt = NOW()
      `;
      
      await connection.execute(query, [
        job.title,
        job.company,
        job.experience,
        job.source,
        job.applicationLink,
        job.domain,
        job.level,
        job.externalId
      ]);
    }
    
    console.log(`✓ Successfully seeded ${jobsData.length} jobs`);
  } catch (error) {
    console.error("Error seeding jobs:", error);
    throw error;
  } finally {
    await connection.end();
  }
}

seedJobs().catch(err => {
  console.error("Fatal error:", err);
  process.exit(1);
});
