import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Jobs table for storing job listings from the daily automation
 */
export const jobs = mysqlTable("jobs", {
  id: int("id").autoincrement().primaryKey(),
  title: varchar("title", { length: 255 }).notNull(),
  company: varchar("company", { length: 255 }).notNull(),
  experience: varchar("experience", { length: 100 }).notNull(),
  source: varchar("source", { length: 100 }).notNull(),
  applicationLink: text("applicationLink").notNull(),
  domain: varchar("domain", { length: 100 }).notNull(),
  level: mysqlEnum("level", ["junior", "mid", "senior"]).notNull(),
  externalId: varchar("externalId", { length: 255 }).unique(), // For deduplication
  roleType: mysqlEnum("roleType", [
    "DevOps Engineer",
    "Cloud Automation Engineer",
    "Platform Engineering",
    "Cloud Infrastructure Engineer",
    "Cloud Security Engineer",
    "DevSecOps",
    "Site Reliability Engineer (SRE)",
    "Continuous Integration (CI/CD)",
    "System Engineer",
    "Cloud Network Engineer",
    "Database Engineer",
    "Cloud Database Engineer",
    "Data Platform Engineer",
    "Machine Learning Engineer (MLOps)",
    "AI Platform Engineer (AIOps)",
    "OutOfScope"
  ]).default("DevOps Engineer"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Job = typeof jobs.$inferSelect;
export type InsertJob = typeof jobs.$inferInsert;