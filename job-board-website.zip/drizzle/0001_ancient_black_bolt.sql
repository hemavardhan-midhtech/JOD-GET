CREATE TABLE `jobs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`title` varchar(255) NOT NULL,
	`company` varchar(255) NOT NULL,
	`experience` varchar(100) NOT NULL,
	`source` varchar(100) NOT NULL,
	`applicationLink` text NOT NULL,
	`domain` varchar(100) NOT NULL,
	`level` enum('junior','mid','senior') NOT NULL,
	`externalId` varchar(255),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `jobs_id` PRIMARY KEY(`id`),
	CONSTRAINT `jobs_externalId_unique` UNIQUE(`externalId`)
);
