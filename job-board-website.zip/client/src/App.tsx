import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch, Link } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import Analytics from "./pages/Analytics";
import { BarChart3 } from "lucide-react";

/**
 * Job Board Application
 * Design: Modern Professional Tech Board with Deep Slate Blue & Cyan Accents
 */
function Router() {
  // make sure to consider if you need authentication for certain routes
  return (
    <Switch>
      <Route path={"/"} component={Home} />
      <Route path={"/analytics"} component={Analytics} />
      <Route path={"/404"} component={NotFound} />
      {/* Final fallback route */}
      <Route component={NotFound} />
    </Switch>
  );
}

function Navigation() {
  return (
    <nav className="bg-white border-b border-slate-200 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
        <Link href="/" className="flex items-center gap-2 font-bold text-lg text-slate-900 hover:text-cyan-500 transition-colors">
          💼 Job Board
        </Link>
        <div className="flex items-center gap-6">
          <Link href="/" className="text-slate-600 hover:text-cyan-500 font-medium transition-colors">
            Jobs
          </Link>
          <Link href="/analytics" className="flex items-center gap-2 text-slate-600 hover:text-cyan-500 font-medium transition-colors">
            <BarChart3 className="w-4 h-4" />
            Analytics
          </Link>
        </div>
      </div>
    </nav>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light">
        <TooltipProvider>
          <Toaster />
          <Navigation />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
