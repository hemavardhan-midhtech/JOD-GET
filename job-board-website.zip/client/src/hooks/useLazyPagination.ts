import { useEffect, useRef, useCallback, useState } from "react";
import { trpc } from "@/lib/trpc";
import type { Job } from "../../../drizzle/schema";

interface UseLazyPaginationOptions {
  pageSize?: number;
  onLoadMore?: (jobs: Job[]) => void;
}

export function useLazyPagination(options: UseLazyPaginationOptions = {}) {
  const { pageSize = 20, onLoadMore } = options;
  
  const [jobs, setJobs] = useState<Job[]>([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [isLoading, setIsLoading] = useState(false);
  const [hasMore, setHasMore] = useState(true);
  const [totalJobs, setTotalJobs] = useState(0);
  
  const observerTarget = useRef<HTMLDivElement>(null);
  const loadingRef = useRef(false);

  // Fetch paginated jobs
  const { data: paginatedData, isLoading: isFetching } = trpc.jobs.paginated.useQuery(
    {
      page: currentPage,
      pageSize,
    },
    {
      enabled: currentPage > 0,
    }
  );

  // Update jobs when new data arrives
  useEffect(() => {
    if (paginatedData) {
      setIsLoading(isFetching);
      
      if (currentPage === 1) {
        // First page - replace all jobs
        setJobs(paginatedData.jobs);
      } else {
        // Subsequent pages - append jobs with deduplication
        setJobs((prev) => {
          // Create a Set of existing job IDs to avoid duplicates
          const existingIds = new Set(prev.map(j => j.id));
          // Filter out jobs that already exist
          const newJobs = paginatedData.jobs.filter(job => !existingIds.has(job.id));
          return [...prev, ...newJobs];
        });
        onLoadMore?.(paginatedData.jobs);
      }
      
      setTotalJobs(paginatedData.total);
      setHasMore(currentPage < paginatedData.totalPages);
    }
  }, [paginatedData, isFetching, currentPage, onLoadMore]);

  // Setup Intersection Observer for lazy loading
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        if (
          entries[0]?.isIntersecting &&
          !loadingRef.current &&
          hasMore &&
          !isFetching
        ) {
          loadingRef.current = true;
          setCurrentPage((prev) => prev + 1);
          
          // Reset the flag after a short delay
          setTimeout(() => {
            loadingRef.current = false;
          }, 500);
        }
      },
      {
        rootMargin: "200px", // Start loading 200px before reaching the bottom
        threshold: 0.01,
      }
    );

    const target = observerTarget.current;
    if (target) {
      observer.observe(target);
    }

    return () => {
      if (target) {
        observer.unobserve(target);
      }
    };
  }, [hasMore, isFetching]);

  // Reset pagination
  const reset = useCallback(() => {
    setJobs([]);
    setCurrentPage(1);
    setHasMore(true);
    setTotalJobs(0);
    loadingRef.current = false;
  }, []);

  // Deduplicate jobs by ID to ensure unique keys
  const uniqueJobs = Array.from(
    new Map(jobs.map(job => [job.id, job])).values()
  );

  return {
    jobs: uniqueJobs,
    isLoading: isFetching,
    hasMore,
    totalJobs,
    currentPage,
    observerTarget,
    reset,
    loadedCount: uniqueJobs.length,
  };
}
