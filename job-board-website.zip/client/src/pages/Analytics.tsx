import { Card } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import {
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  LineChart,
  Line,
} from "recharts";
import { Loader2, TrendingUp, Briefcase, Building2, Zap } from "lucide-react";

const COLORS = [
  "#00d9ff",
  "#0099cc",
  "#006699",
  "#003366",
  "#1e3a5f",
  "#2d5a8c",
  "#3d7ab9",
  "#4d9ae6",
];

export default function Analytics() {
  // Fetch analytics data
  const { data: stats, isLoading: statsLoading } = trpc.analytics.stats.useQuery();
  const { data: jobsByLevel, isLoading: levelLoading } = trpc.analytics.jobsByLevel.useQuery();
  const { data: jobsByDomain, isLoading: domainLoading } = trpc.analytics.jobsByDomain.useQuery();
  const { data: topCompanies, isLoading: companiesLoading } = trpc.analytics.topCompanies.useQuery({
    limit: 10,
  });
  const { data: jobsBySource, isLoading: sourceLoading } = trpc.analytics.jobsBySource.useQuery();
  const { data: experienceDistribution, isLoading: expLoading } = trpc.analytics.experienceDistribution.useQuery();

  const isLoading =
    statsLoading ||
    levelLoading ||
    domainLoading ||
    companiesLoading ||
    sourceLoading ||
    expLoading;

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-background to-secondary flex items-center justify-center">
        <div className="flex items-center gap-2 text-slate-600">
          <Loader2 className="w-6 h-6 animate-spin" />
          <span className="text-lg">Loading analytics...</span>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-secondary">
      {/* Header */}
      <div className="bg-gradient-to-r from-slate-900 to-slate-800 text-white py-12 px-4">
        <div className="max-w-7xl mx-auto">
          <h1 className="text-4xl font-bold mb-2">
            Job Market <span className="text-cyan-400">Analytics</span>
          </h1>
          <p className="text-slate-300">
            Comprehensive insights into DevOps, SRE, and Cloud job market trends
          </p>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 py-12">
        {/* Key Statistics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          <Card className="p-6 bg-white border-l-4 border-l-cyan-500">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-slate-600 text-sm font-medium">Total Jobs</p>
                <p className="text-3xl font-bold text-slate-900 mt-2">
                  {stats?.totalJobs || 0}
                </p>
              </div>
              <Briefcase className="w-12 h-12 text-cyan-500 opacity-20" />
            </div>
          </Card>

          <Card className="p-6 bg-white border-l-4 border-l-blue-500">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-slate-600 text-sm font-medium">Companies</p>
                <p className="text-3xl font-bold text-slate-900 mt-2">
                  {stats?.totalCompanies || 0}
                </p>
              </div>
              <Building2 className="w-12 h-12 text-blue-500 opacity-20" />
            </div>
          </Card>

          <Card className="p-6 bg-white border-l-4 border-l-purple-500">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-slate-600 text-sm font-medium">Domains</p>
                <p className="text-3xl font-bold text-slate-900 mt-2">
                  {stats?.totalDomains || 0}
                </p>
              </div>
              <Zap className="w-12 h-12 text-purple-500 opacity-20" />
            </div>
          </Card>

          <Card className="p-6 bg-white border-l-4 border-l-green-500">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-slate-600 text-sm font-medium">Avg Jobs/Company</p>
                <p className="text-3xl font-bold text-slate-900 mt-2">
                  {stats?.averageJobsPerCompany || 0}
                </p>
              </div>
              <TrendingUp className="w-12 h-12 text-green-500 opacity-20" />
            </div>
          </Card>
        </div>

        {/* Charts Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
          {/* Jobs by Experience Level */}
          <Card className="p-6 bg-white">
            <h2 className="text-xl font-bold text-slate-900 mb-6">
              Jobs by Experience Level
            </h2>
            {jobsByLevel && jobsByLevel.length > 0 ? (
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={jobsByLevel}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                  <XAxis dataKey="level" stroke="#64748b" />
                  <YAxis stroke="#64748b" />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "#1e293b",
                      border: "1px solid #64748b",
                      borderRadius: "8px",
                      color: "#f1f5f9",
                    }}
                  />
                  <Bar dataKey="count" fill="#00d9ff" radius={[8, 8, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <p className="text-slate-500">No data available</p>
            )}
          </Card>

          {/* Jobs by Domain */}
          <Card className="p-6 bg-white">
            <h2 className="text-xl font-bold text-slate-900 mb-6">
              Jobs by Domain
            </h2>
            {jobsByDomain && jobsByDomain.length > 0 ? (
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={jobsByDomain}
                    dataKey="count"
                    nameKey="domain"
                    cx="50%"
                    cy="50%"
                    outerRadius={100}
                    label={({ domain, percentage }) => `${domain} ${percentage}%`}
                  >
                    {jobsByDomain.map((_, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "#1e293b",
                      border: "1px solid #64748b",
                      borderRadius: "8px",
                      color: "#f1f5f9",
                    }}
                  />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <p className="text-slate-500">No data available</p>
            )}
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
          {/* Jobs by Source */}
          <Card className="p-6 bg-white">
            <h2 className="text-xl font-bold text-slate-900 mb-6">
              Jobs by Source
            </h2>
            {jobsBySource && jobsBySource.length > 0 ? (
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={jobsBySource} layout="vertical">
                  <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                  <XAxis type="number" stroke="#64748b" />
                  <YAxis dataKey="source" type="category" stroke="#64748b" width={100} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "#1e293b",
                      border: "1px solid #64748b",
                      borderRadius: "8px",
                      color: "#f1f5f9",
                    }}
                  />
                  <Bar dataKey="count" fill="#0099cc" radius={[0, 8, 8, 0]} />
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <p className="text-slate-500">No data available</p>
            )}
          </Card>

          {/* Experience Distribution */}
          <Card className="p-6 bg-white">
            <h2 className="text-xl font-bold text-slate-900 mb-6">
              Required Experience Distribution
            </h2>
            {experienceDistribution && experienceDistribution.length > 0 ? (
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={experienceDistribution}
                    dataKey="count"
                    nameKey="experience"
                    cx="50%"
                    cy="50%"
                    outerRadius={100}
                    label={({ experience, percentage }) => `${experience} ${percentage}%`}
                  >
                    {experienceDistribution.map((_, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "#1e293b",
                      border: "1px solid #64748b",
                      borderRadius: "8px",
                      color: "#f1f5f9",
                    }}
                  />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <p className="text-slate-500">No data available</p>
            )}
          </Card>
        </div>

        {/* Top Hiring Companies */}
        <Card className="p-6 bg-white">
          <h2 className="text-xl font-bold text-slate-900 mb-6">
            Top 10 Hiring Companies
          </h2>
          {topCompanies && topCompanies.length > 0 ? (
            <div className="space-y-4">
              {topCompanies.map((company, index) => (
                <div key={index} className="flex items-center justify-between p-4 bg-slate-50 rounded-lg">
                  <div className="flex items-center gap-4 flex-1">
                    <div className="flex items-center justify-center w-10 h-10 bg-cyan-500 text-white font-bold rounded-lg">
                      {index + 1}
                    </div>
                    <div className="flex-1">
                      <p className="font-semibold text-slate-900">{company.company}</p>
                      <p className="text-sm text-slate-600">{company.percentage}% of all jobs</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-2xl font-bold text-cyan-500">{company.jobCount}</p>
                    <p className="text-xs text-slate-600">positions</p>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-slate-500">No data available</p>
          )}
        </Card>
      </div>
    </div>
  );
}
