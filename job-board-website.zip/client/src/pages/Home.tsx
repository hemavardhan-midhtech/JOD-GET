import { useState, useMemo } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { Search, ExternalLink, Filter, Loader2 } from "lucide-react";
import { useLazyPagination } from "@/hooks/useLazyPagination";
import type { Job } from "../../../drizzle/schema";

/**
 * Design Philosophy: Modern Professional Tech Board
 * - Deep slate blue (#1e3a5f) primary with bright cyan (#00d9ff) accents
 * - Asymmetric layout: sidebar filters + main grid
 * - Glassmorphism cards with subtle hover effects
 * - Smooth animations and micro-interactions
 */

function JobCard({ job }: { job: Job }) {
  return (
    <Card className="p-6 hover:shadow-lg transition-all duration-300 border-l-4 border-l-cyan-500 bg-white/95 backdrop-blur">
      <div className="flex items-start justify-between gap-4 mb-4">
        <div className="flex-1">
          <h3 className="text-lg font-bold text-slate-900 mb-1">{job.title}</h3>
          <p className="text-slate-600 font-medium">{job.company}</p>
        </div>
        <a
          href={job.applicationLink}
          target="_blank"
          rel="noopener noreferrer"
          className="flex-shrink-0"
        >
          <Button className="bg-cyan-500 hover:bg-cyan-600 text-white gap-2">
            Apply Now <ExternalLink className="w-4 h-4" />
          </Button>
        </a>
      </div>

      <div className="flex flex-wrap gap-2 mb-4">
        <Badge variant="secondary" className="bg-slate-900 text-cyan-400">
          {job.domain}
        </Badge>
        <Badge variant="secondary" className="capitalize bg-slate-800 text-cyan-300">
          {job.level}
        </Badge>
        <Badge variant="outline" className="text-slate-600">
          {job.source}
        </Badge>
      </div>

      <div className="flex items-center gap-4 text-sm text-slate-600">
        <span>📊 {job.experience}</span>
        <span>🌍 United States</span>
      </div>
    </Card>
  );
}

export default function Home() {
  const { user } = useAuth();
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedLevel, setSelectedLevel] = useState<string | null>(null);
  const [selectedSource, setSelectedSource] = useState<string | null>(null);
  const [showFilters, setShowFilters] = useState(false);

  // Use lazy-loading pagination hook
  const {
    jobs,
    isLoading,
    hasMore,
    totalJobs,
    loadedCount,
    observerTarget,
  } = useLazyPagination({
    pageSize: 20,
  });

  // Extract unique values for filters from loaded jobs
  const levels = Array.from(new Set(jobs.map((job) => job.level)));
  const sources = Array.from(new Set(jobs.map((job) => job.source)));

  // Filter jobs based on search and selected filters
  const filteredJobs = useMemo(() => {
    return jobs.filter((job) => {
      const matchesSearch =
        searchQuery === "" ||
        job.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        job.company.toLowerCase().includes(searchQuery.toLowerCase()) ||
        job.domain.toLowerCase().includes(searchQuery.toLowerCase());

      const matchesLevel = selectedLevel === null || job.level === selectedLevel;
      const matchesSource =
        selectedSource === null || job.source === selectedSource;

      return matchesSearch && matchesLevel && matchesSource;
    });
  }, [searchQuery, selectedLevel, selectedSource, jobs]);

  const toggleLevel = (level: string) => {
    setSelectedLevel(selectedLevel === level ? null : level);
  };

  const toggleSource = (source: string) => {
    setSelectedSource(selectedSource === source ? null : source);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-secondary">
      {/* Hero Section */}
      <div
        className="relative h-80 bg-cover bg-center overflow-hidden"
        style={{
          backgroundImage:
            "url('https://images.unsplash.com/photo-1517694712202-14dd9538aa97?w=1200&h=400&fit=crop')",
        }}
      >
        <div className="absolute inset-0 bg-gradient-to-r from-slate-900/90 via-slate-900/70 to-transparent flex items-center justify-center">
          <div className="text-center text-white max-w-2xl px-6">
            <h1 className="text-5xl font-bold mb-4">
              DevOps & SRE <span className="text-cyan-400">Job Board</span>
            </h1>
            <p className="text-xl text-slate-300">
              Discover curated opportunities in DevOps, Site Reliability Engineering, Cloud
              Infrastructure, and Database roles from top-tier US-based companies. Updated
              daily with fresh listings.
            </p>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Sidebar Filters */}
          <div className="lg:col-span-1">
            <div className="sticky top-4 space-y-6">
              <div className="flex items-center justify-between lg:hidden mb-4">
                <h2 className="text-xl font-bold text-slate-900">Filters</h2>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setShowFilters(!showFilters)}
                  className="lg:hidden"
                >
                  <Filter className="w-5 h-5" />
                </Button>
              </div>

              {(showFilters || window.innerWidth >= 1024) && (
                <>
                  {/* Experience Level Filter */}
                  <div className="bg-white rounded-lg p-6 shadow-sm border border-slate-200">
                    <h3 className="font-bold text-slate-900 mb-4 flex items-center gap-2">
                      <span className="text-cyan-500">🎯</span> Experience Level
                    </h3>
                    <div className="space-y-3">
                      {levels.map((level) => (
                        <button
                          key={level}
                          onClick={() => toggleLevel(level)}
                          className={`w-full text-left px-4 py-2 rounded-lg font-medium transition-all ${
                            selectedLevel === level
                              ? "bg-cyan-500 text-white"
                              : "bg-slate-100 text-slate-700 hover:bg-slate-200"
                          }`}
                        >
                          {level.charAt(0).toUpperCase() + level.slice(1)}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Job Source Filter */}
                  <div className="bg-white rounded-lg p-6 shadow-sm border border-slate-200">
                    <h3 className="font-bold text-slate-900 mb-4 flex items-center gap-2">
                      <span className="text-cyan-500">📍</span> Job Source
                    </h3>
                    <div className="space-y-3">
                      {sources.map((source) => (
                        <button
                          key={source}
                          onClick={() => toggleSource(source)}
                          className={`w-full text-left px-4 py-2 rounded-lg font-medium transition-all text-sm ${
                            selectedSource === source
                              ? "bg-cyan-500 text-white"
                              : "bg-slate-100 text-slate-700 hover:bg-slate-200"
                          }`}
                        >
                          {source}
                        </button>
                      ))}
                    </div>
                  </div>
                </>
              )}
            </div>
          </div>

          {/* Job Listings */}
          <div className="lg:col-span-3">
            {/* Search Bar */}
            <div className="mb-8">
              <div className="relative">
                <Search className="absolute left-4 top-3.5 w-5 h-5 text-slate-400" />
                <Input
                  type="text"
                  placeholder="Search by job title, company, or domain..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-12 py-3 text-lg border-2 border-slate-200 focus:border-cyan-500 rounded-lg"
                />
              </div>
            </div>

            {/* Results Counter */}
            <div className="mb-6">
              <p className="text-slate-600 font-medium">
                Showing {filteredJobs.length} of {loadedCount} loaded jobs
                {totalJobs > 0 && ` (${totalJobs} total available)`}
              </p>
            </div>

            {/* Job Cards Grid */}
            {filteredJobs.length > 0 ? (
              <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-1">
                {filteredJobs.map((job) => (
                  <JobCard key={job.id} job={job} />
                ))}
              </div>
            ) : (
              <Card className="p-12 text-center">
                <p className="text-lg text-slate-600">
                  {jobs.length === 0
                    ? "Loading jobs..."
                    : "No jobs match your filters. Try adjusting your search criteria."}
                </p>
              </Card>
            )}

            {/* Lazy Loading Trigger */}
            {hasMore && (
              <div
                ref={observerTarget}
                className="mt-12 flex justify-center items-center py-8"
              >
                {isLoading && (
                  <div className="flex items-center gap-2 text-slate-600">
                    <Loader2 className="w-5 h-5 animate-spin" />
                    <span>Loading more jobs...</span>
                  </div>
                )}
              </div>
            )}

            {/* End of Results */}
            {!hasMore && jobs.length > 0 && (
              <div className="mt-12 text-center py-8">
                <p className="text-slate-600 font-medium">
                  ✓ You've reached the end of available jobs
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
